PASTE KEY HERE - ' '
Also works without key